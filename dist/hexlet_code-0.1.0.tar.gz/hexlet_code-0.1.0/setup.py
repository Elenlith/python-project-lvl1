# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Five simple math games',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Elenlith/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/Elenlith/python-project-lvl1/actions)\n<a href="https://codeclimate.com/github/Elenlith/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/70e35268de92ee07343e/maintainability" /></a>\n\nThe project includes five simple math games: Parity Check prompts user to identify if the randomly generated number is even or not, Calculator suggests user to solve the simple math expression, Greatest Common Divisor asks to find the GCD of the two random numbers, Progression requests to identify the missing member of arithmetic progression and Prime Number asks user if the random number is prime or not. User wins the game if he/she answers correctly to the three consecutive questions. The below asciinemas show how to install the project and run each game.\n\nParity Check game:\n<a href="https://asciinema.org/a/n0BmPfkqR492vltWglWersLUw" target="_blank"><img src="https://asciinema.org/a/n0BmPfkqR492vltWglWersLUw.svg" /></a>\nCalculator game: \n<a href="https://asciinema.org/a/Yf3fhJHXU3GS0YFnAA2r3kbHq" target="_blank"><img src="https://asciinema.org/a/Yf3fhJHXU3GS0YFnAA2r3kbHq.svg" /></a>\nGreatest Common Divisor game:\n<a href="https://asciinema.org/a/BlN0KiZkRDdYziZwn9QFr8Kep" target="_blank"><img src="https://asciinema.org/a/BlN0KiZkRDdYziZwn9QFr8Kep.svg" /></a>\nProgression game:\n<a href="https://asciinema.org/a/aQng5kGmwi3jnWSjEu1ZpGVMp" target="_blank"><img src="https://asciinema.org/a/aQng5kGmwi3jnWSjEu1ZpGVMp.svg" /></a>\nPrime Number game:\n<a href="https://asciinema.org/a/YDIiYTyGl4pPQqTnvgdgANN8b" target="_blank"><img src="https://asciinema.org/a/YDIiYTyGl4pPQqTnvgdgANN8b.svg" /></a>\n',
    'author': 'Kirill Mischenkov aka Elenlith',
    'author_email': 'mishchenkov@list.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/Elenlith/python-project-lvl1',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
