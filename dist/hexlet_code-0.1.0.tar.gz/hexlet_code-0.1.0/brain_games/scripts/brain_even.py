from brain_games.engine import launch_engine
import brain_games.games.even


def main():
    launch_engine(brain_games.games.even)


if __name__ == '__main__':
    main()
