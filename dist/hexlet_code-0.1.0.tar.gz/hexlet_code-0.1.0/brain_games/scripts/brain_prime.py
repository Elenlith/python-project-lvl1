from brain_games.engine import launch_engine
import brain_games.games.prime


def main():
    launch_engine(brain_games.games.prime)


if __name__ == '__main__':
    main()
