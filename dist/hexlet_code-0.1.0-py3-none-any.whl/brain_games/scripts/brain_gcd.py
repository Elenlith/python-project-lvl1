from brain_games.engine import launch_engine
import brain_games.games.gcd


def main():
    launch_engine(brain_games.games.gcd)


if __name__ == '__main__':
    main()
